Original version developed by Jim R. Wilson (jimbojw)
Subsequent improvements added by (alphabetical order)

Alexia E. Smith (Alexia)
Andrew Whitworth (Whiteknight)
Mohammed Derakhshani (Mderakhs)